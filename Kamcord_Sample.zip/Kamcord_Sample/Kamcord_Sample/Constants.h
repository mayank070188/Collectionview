//
//  Constants.h
//  Kamcord_Sample
//
//  Created by Mayank Mathur on 8/29/16.
//  Copyright © 2016 Mayank Mathur. All rights reserved.
//

#ifndef Constants_h
#define Constants_h


#endif /* Constants_h */

#define FEEDURL @"https://api.staging.kamcord.com/v1/feed/set/featuredShots"
#define COUNT @"20"
#define CLIENTNAME @"ios"
#define DEVICETOKEN @"abc123"
