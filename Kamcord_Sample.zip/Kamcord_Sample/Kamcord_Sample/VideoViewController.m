//
//  VideoViewController.m
//  Kamcord_Sample
//
//  Created by Mayank Mathur on 8/21/16.
//  Copyright © 2016 Mayank Mathur. All rights reserved.
//

#import "VideoViewController.h"



@interface VideoViewController ()

@end


@implementation VideoViewController

@synthesize videoString;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    playerViewController = [[AVPlayerViewController alloc] init];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    NSURL *url = [NSURL URLWithString:videoString];
    
    AVURLAsset *asset = [AVURLAsset assetWithURL: url];
    AVPlayerItem *item = [AVPlayerItem playerItemWithAsset: asset];
    
    AVPlayer * player = [[AVPlayer alloc] initWithPlayerItem: item];
    playerViewController.player = player;
    [playerViewController.view setFrame:CGRectMake(0, self.navigationController.navigationBar.frame.size.height, self.view.bounds.size.width, (self.view.bounds.size.height - (self.navigationController.navigationBar.frame.size.height + self.tabBarController.tabBar.frame.size.height)))];
    
    playerViewController.showsPlaybackControls = NO;
    
    [self.view addSubview:playerViewController.view];
    
    [player play];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
