//
//  MyLayout.h
//  Kamcord_Sample
//
//  Created by Mayank Mathur on 8/31/16.
//  Copyright © 2016 Mayank Mathur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyLayout : UICollectionViewFlowLayout

@end
