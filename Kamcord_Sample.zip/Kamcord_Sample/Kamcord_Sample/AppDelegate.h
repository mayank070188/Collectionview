//
//  AppDelegate.h
//  Kamcord_Sample
//
//  Created by Mayank Mathur on 8/20/16.
//  Copyright © 2016 Mayank Mathur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

